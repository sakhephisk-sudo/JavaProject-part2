
     
package registrario.paer1;

/**
 *
 * @author Student
 */
import java.util.Scanner;

public class login {

    // Login user
    public static boolean loginUser(
            Scanner input,
            String storedusername,
            String storedPassword,
            String name,
            String surname) {

        System.out.println("====== LOGIN PAGE ======");

        while (true) {

            System.out.println("Enter your username:");
            String enteredusername = input.nextLine();

            System.out.println("Enter your password:");
            String enteredPassword = input.nextLine();

            if (enteredusername.equals(storedusername)
                    && enteredPassword.equals(storedPassword)) {

                System.out.println(
                        "Welcome "
                        + name
                        + " "
                        + surname
                        + ", it is great to see you again."
                );

                return true;

            } else {

                System.out.println(
                        "Username or password incorrect, please try again."
                );
            }
        }
    }

    // Return login status with matching parameters
    public static String returnLoginStatus(
            boolean loginSuccessful, 
            String name, 
            String surname) {

        if (loginSuccessful) {
            return "Welcome " + name + " " + surname + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Overloaded helper method
    public static String returnLoginStatus() { 
        return "Login successful";
    }
}

